#!/bin/bash

date

current_time=$(date +%s)

echo "Current epoch time: $current_time"
echo "Doubled epoch time: $((current_time * 2))"

for i in {1..20}; do
	echo "$i"
done

